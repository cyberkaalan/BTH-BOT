let handler  = async (m, { conn, usedPrefix: _p }) => {
  conn.reply(m.chat, `
╠═〘 BTH BOAT 〙 ═
╠➥  Made in javascript via NodeJs
╠➥ Rec: ARAKKAL BHASI [CYBER KAALAN]
╠➥ Script: ARAKKAL BHASI
║
╠➥
╠➥ INSTAGRAM : https://instagram.com/bhasi_bth_?igshid=fi0ooi3fd9lf
╠➥ You tube : https://youtube.com/channel/UCO2NeFSB2nq-v1z3Ej95vLw
║
╠═〘 Thanks To 〙 ═
╠➥ CYBER MAC MODS
╠➥ARAKKAL THARAVAAD
╠➥KURISHINGAL EMPIRE
║
╠➥ [BOAT]
╠➥ MAKE GROUP ADMIN 
╠➥ TURN ON YOUR DATA
╠➥ CONTACT : wa.me//+918891903813
║
║>Request? wa.me//+918891903813
║
╠═〘 BHT BOAT 〙 ═
`.trim(), m)
}
handler.command = /^(info)$/i
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null

module.exports = handler

